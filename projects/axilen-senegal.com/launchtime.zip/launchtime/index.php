<?php global $shortname; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php warrior_title(); ?></title>
<?php warrior_meta(); ?>

<?php if( get_option($shortname.'_maintenance_status') == 'No' || current_user_can('administrator') ): // Check if the site is in maintenance mod ?>
	<?php if ( get_option($shortname.'_ie6_warning') == "Yes" && strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE 6.') == true) : ?>
    	<link href="<?php bloginfo('template_url'); ?>/css/ie6-warning.css" rel="stylesheet" type="text/css" media="screen" />
    <?php else: ?>
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
        <?php wp_head(); ?>
    <?php endif; ?>
<?php else: ?>
    <link href="<?php bloginfo('template_url'); ?>/css/maintenance.css" rel="stylesheet" type="text/css" media="screen" />
<?php endif; ?>
</head>

<body <?php body_class(); ?>>

<?php warrior_maintenance(); warrior_ie6_warning (); ?>

	<!-- START: HEADER -->
	<div id="header" class="clearfix">
		<div class="container">
		
			<div class="logo">
				<?php warrior_logo(); ?>
			</div>
			
			<?php if ( get_option($shortname.'_note_about') != '' ) : ?>
			<div class="message clearfix">
				<?php echo stripslashes( wpautop( get_option($shortname.'_note_about') ) ); ?>
			</div>
			<?php endif; ?>
			
		</div>
	</div>
	<!-- END: HEADER -->

	<!-- START: MAIN CONTENT -->
	<div id="main-content" class="clearfix">
		<div class="container">
	
			<?php if ( get_option($shortname.'_launch_date') != '' && get_option($shortname.'_launch_time') != '' ) : ?>
			<div class="countdown clearfix">
				<h3 id="launch-text"><?php _e('Our site will launch in', 'warrior'); ?></h3>
				<div id="time" class="timer"></div>
			</div>
			<?php endif; ?>
					
			<?php if ( get_option($shortname.'_feedburner_id') != '' ) : ?>
			<div class="newsletter clearfix">
				<p><?php _e('Want to know when we launch? Signup to our newsletter.', 'warrior'); ?></p>
				<form action="http://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open('http://feedburner.google.com/fb/a/mailverify?uri=<?php echo get_option($shortname.'_feedburner_id'); ?>', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true">
					<input type="text" value="" name="email" class="newsletterform" />
					<input type="hidden" value="<?php echo get_option($shortname.'_feedburner_id'); ?>" name="uri"/>
					<input type="hidden" name="loc" value="en_US"/>
					<input type="submit" value="<?php _e('Signup Now', 'warrior'); ?>" class="newslettersubmit" />
				</form>
			</div>
			<?php endif; ?>
					
			<div class="socialmedia clearfix">
				<?php warrior_social_icons(); ?>
			</div>

		</div>
	</div>
	<!-- END: MAIN CONTENT -->
	
	<!-- START: FOOTER -->
	<div id="footer" class="clearfix">
		<p><?php _e('Powered by', 'warrior'); ?> <a href="http://wordpress.org"><?php _e('WordPress', 'warrior'); ?></a>. <?php _e('Designed by' ,'warrior'); ?> <a href="http://www.themewarrior.com"><img src="<?php bloginfo('template_url') ?>/images/logo-themewarrior.png" alt="<?php _e('Premium WordPress Themes', 'warrior'); ?>" title="<?php _e('Premium WordPress Themes', 'warrior'); ?>" /></a></p>
	</div>
	<!-- END: FOOTER -->
	
<?php wp_footer(); ?>
</body>
</html>