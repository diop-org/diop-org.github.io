    <div id="maintenance">
    	<div class="container"
        	<div class="inside">
                <h1><?php echo stripslashes( get_option($shortname.'_maintenance_title') ); ?></h1>
                <p><?php echo stripslashes( get_option($shortname.'_maintenance_text') ); ?></p>
            </div>
        </div>
    </div>
</body>
</html>