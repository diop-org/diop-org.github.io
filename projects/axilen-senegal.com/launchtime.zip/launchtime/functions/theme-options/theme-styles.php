<?php
/**
 * Warrior Javascript & CSS
 *
 * Function to load Javascript and CSS 
 * for theme frontend
 */
function warrior_enqueue_scripts() {
	global $shortname, $pagenow;

	// Only load these scripts on frontend
	if( !is_admin() && $pagenow != 'wp-login.php' ) {
		
			// Load all Javascript files
			wp_enqueue_script('jquery');
			wp_enqueue_script('thickbox');
			wp_enqueue_script( 'updowntimer', get_bloginfo('template_directory').'/js/jquery.updowntimer.js' );
			
			// Load all CSS files		
			wp_register_style('style', get_bloginfo('stylesheet_directory').'/style.css', array(), false, 'screen');
			wp_enqueue_style('style');
			
			// Check if Glegoo font is selected
			if( get_option($shortname.'_font') == "Glegoo" ) {
				wp_register_style('font-glegoo', 'http://fonts.googleapis.com/css?family=Glegoo', array(), false, 'screen');
				wp_enqueue_style('font-glegoo');
			}
			
			// Load CSS file for theme style
			if( get_option($shortname.'_style') <> "" ) {
				wp_register_style($shortname.'_style', get_bloginfo('template_url').'/styles/'. get_option($shortname.'_style').'/'.get_option($shortname.'_style').'.css', array(), false, 'screen');
				wp_enqueue_style($shortname.'_style');
			} else {
				wp_register_style($shortname.'_style', get_bloginfo('template_url').'/styles/default/default.css', array(), false, 'screen');
				wp_enqueue_style($shortname.'_style');
			}
			
			// Load custom CSS file
			wp_register_style('custom', get_bloginfo('template_url').'/custom.css', array(), false, 'screen');
			wp_enqueue_style('custom');
		
	} else {
		wp_enqueue_style( 'jquery-ui-datepicker', get_bloginfo('template_directory').'/css/jquery.ui.datepicker.css' );
		wp_enqueue_style( 'jquery-ui-datepicker' );
		wp_enqueue_script( 'jquery-ui-custom', get_bloginfo('template_directory').'/js/jquery-ui-1.8.16.custom.min.js', '', '1.8.16' );
		wp_enqueue_script( 'jquery-ui-timepicker', get_bloginfo('template_directory').'/js/jquery-ui-timepicker-addon.js' );
	}
}
add_action( 'init', 'warrior_enqueue_scripts' );


/**
 * Warrior Javascript & CSS
 *
 * Function to load inline 
 * Javascript and CSS files
 */
function warrior_js_css() {
	global $shortname;
	
?>
	<style type="text/css">
	<?php if( get_option($shortname.'_enable_color_settings') == "Yes" ) : ?>
        /* Load custom styles defined in WarriorPanel */
		body { 
			font-family: <?php echo get_option($shortname.'_font'); ?>;
			<?php if( get_option($shortname.'_font') != 'Glegoo' ) : ?> 
			letter-spacing: 0;
			<?php endif; ?>
			}
		<?php if( get_option($shortname.'_color_text') != '' ) : ?> 
			.message { color: <?php echo get_option($shortname.'_color_text'); ?>; }
		<?php endif; ?>
 		<?php if( get_option($shortname.'_color_link') != '' ) : ?> 
			a, a:link { color: <?php echo get_option($shortname.'_color_link'); ?>; }
		<?php endif; ?>
		<?php if( get_option($shortname.'_color_hover') != '' ) : ?> 
			a:hover { color: <?php echo get_option($shortname.'_color_hover'); ?>; }
		<?php endif; ?>
		<?php if( get_option($shortname.'_color_visited') != '' ) : ?> 
			a:visited { color: <?php echo get_option($shortname.'_color_visited'); ?>; }
		<?php endif; ?>
	<?php endif; ?>
		
	<?php if( get_option($shortname.'_style') <> "" ) :?>
		<?php echo get_option($shortname.'_custom_css'); ?>
	<?php endif; ?>
	</style>

    <script type="text/javascript">
		//<![CDATA[
		<?php 
		$time = str_replace( ' ','', get_option($shortname.'_launch_time').':00' );
		$date = get_option($shortname.'_launch_date');
		
		$target_time = strtotime($date.' '.$time);
		$now_time = current_time('timestamp');
		
		$target	= date('F d, Y G:i:s', $target_time);
		$now = date('F d, Y G:i:s', $now_time);
		
		$different = $target_time - $now_time;
		?>
		
        jQuery(document).ready(function($) {
			<?php if ( $different > 0 ) { ?>
			// Countdown Timer
			new CountDown('<?php echo $target; ?>', 'time'); 
			<?php } else { ?>
			// Countup Timer
			new CountUp('<?php echo $target; ?>', 'time');
			$('h3#launch-text').text('<?php _e('Our site has been launched for', 'warrior'); ?>');
			<?php } ?>
					
			// Set newletter box value
			$('input.newsletterform').val('<?php _e('Enter your email address...', 'warrior'); ?>');
			$('input.newsletterform').blur(function(){
				if ($('input.newsletterform').val() == ''){
					$('input.newsletterform').val('<?php _e('Enter your email address...', 'warrior'); ?>');
				}
			});
			$('input.newsletterform').focus(function(){
				if ($('input.newsletterform').val() == '<?php _e('Enter your email address...', 'warrior'); ?>'){
					$('input.newsletterform').val('');
				}
			});
		
		});
		//]]>
    </script>

	<!--[if lte IE 6]>
		<link href="<?php bloginfo('template_url'); ?>/css/ie6.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/DD_belatedPNG_0.0.8a-min.js"></script>
		<script>
			DD_belatedPNG.fix('*');
        </script>
	<![endif]-->
	<!--[if IE 7]>
		<link href="<?php bloginfo('template_url'); ?>/css/ie7.css" rel="stylesheet" type="text/css" />
	<![endif]-->
	<!--[if IE 8]>
   		<link rel="stylesheet" media="screen" type="text/css" href="<?php bloginfo('template_url') ?>/css/ie8.css" />
	<![endif]-->

<?php
}
add_action( 'wp_head', 'warrior_js_css' );


function warrior_admin_time() {
	global $shortname;
?>
    <script type="text/javascript">
		//<![CDATA[
        jQuery(document).ready(function($) {
			$('#<?php echo $shortname; ?>_launch_date').datepicker({
				showButtonPanel: true
			});
			$('#<?php echo $shortname; ?>_launch_time').timepicker({
			});
		});
		//]]>
    </script>
<?php
}
add_action( 'admin_footer', 'warrior_admin_time' );
?>