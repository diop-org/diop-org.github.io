<?php
/**
* List of theme support functions
*/


// Check if the function exist
if ( function_exists( 'add_theme_support' ) ){
	// Add custom background feature 
	add_custom_background();
	
	// Add default posts and comments RSS feed links to head
	add_theme_support( 'automatic-feed-links' );
}


// Theme Localization
load_theme_textdomain('warrior', get_template_directory().'/lang');

// Set maximum image width displayed in a single post or page
if ( ! isset( $content_width ) ) {
	$content_width = 740;
}
?>