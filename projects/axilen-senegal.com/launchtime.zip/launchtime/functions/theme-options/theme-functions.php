<?php
/**
 * Theme Custom Functions
 *
 * Functions used in the theme
 */
 
?>