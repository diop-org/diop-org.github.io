<?php
/**
 * Warrior Widgets
 * Register sidebar & load widget files
*/

?>