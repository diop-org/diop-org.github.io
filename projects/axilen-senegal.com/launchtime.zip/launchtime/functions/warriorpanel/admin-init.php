<?php
/**
 * This file will load all necessary WarriorPanel files
 */

require_once(TEMPLATEPATH . "/functions/warriorpanel/admin-panel.php"); // Load WarriorPanel
require_once(TEMPLATEPATH . "/functions/warriorpanel/admin-options.php"); // Load theme options
require_once(TEMPLATEPATH . "/functions/warriorpanel/admin-functions.php"); // Load theme functions
require_once(TEMPLATEPATH . "/functions/warriorpanel/admin-seo.php"); // Load SEO function
require_once(TEMPLATEPATH . "/functions/warriorpanel/admin-shortcodes.php"); // Load shortcodes function
?>