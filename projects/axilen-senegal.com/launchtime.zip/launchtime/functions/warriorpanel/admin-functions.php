<?php
/**
 * Warrior Maintenance
 *
 * Function to load maintenance page
 */

function warrior_maintenance() {
	global $shortname;
	
	if( get_option($shortname.'_maintenance_status') == 'Yes' && !current_user_can('administrator') ) {
		include( TEMPLATEPATH . '/includes/maintenance.php' );
		exit;
	} elseif ( get_option($shortname.'_maintenance_status') == 'Yes' && current_user_can('administrator') ) {
		$maintenance_text_admin = stripslashes( get_option($shortname.'_maintenance_text_admin') );
		echo "<div id=\"maintenance-notice\">". $maintenance_text_admin ."</div>";
	}
}

/**
 * Warrior Admin Bar
 *
 * Function to display warriorpanel submenu on wp admin bar
 */
function warrior_admin_bar_render() {
    global $wp_admin_bar, $shortname;
	
	$args = array();
	$args[] = array(
        'id' => 'warriorpanel',
        'title' => 'WarriorPanel',
        'href' => admin_url( 'admin.php?page=warriorpanel')
    );
	$args[] = array(
        'parent' => 'warriorpanel',
        'id' => 'warriorpanel_options',
        'title' => 'Theme Options',
        'href' => admin_url( 'admin.php?page=warriorpanel')
    );
	$args[] = array(
        'parent' => 'warriorpanel',
        'id' => 'warriorpanel_framework',
        'title' => 'Framework',
        'href' => admin_url( 'admin.php?page=warriorpanel_framework')
    );
	$args[] = array(
        'parent' => 'warriorpanel',
        'id' => 'warriorpanel_seo',
        'title' => 'SEO',
        'href' => admin_url( 'admin.php?page=warriorpanel_seo')
    );
	$args[] = array(
        'parent' => 'warriorpanel',
        'id' => 'warriorpanel_update',
        'title' => 'Update Framework',
        'href' => admin_url( 'admin.php?page=warriorpanel_update')
    );
	$args[] = array(
        'parent' => 'warriorpanel',
        'id' => 'warriorpanel_themes',
        'title' => 'Themes',
        'href' => admin_url( 'admin.php?page=warriorpanel_themes')
    );
	
	if ( get_option($shortname.'_warrior_admin_bar') == 'Yes' ) :
		foreach ( $args as $arg ) {
			$wp_admin_bar->add_menu( $arg );
		}
	else :
		$wp_admin_bar->remove_menu( 'warriorpanel' );
	endif;
}
add_action('admin_bar_menu', 'warrior_admin_bar_render', 1000);


/**
 * Warrior Generators
 *
 * Function to generate meta generators containing theme name,
 * theme version and WarriorPanel version
 */
 
function warrior_generators() {
	global $shortname, $themename, $version, $warrior_panel_version;
	
	if( get_option($shortname.'_generators') == "Yes" ) {
		$output = '';
		$output .= '<meta name="generator" content="'. $themename .' '. $version .'" />'. "\n";
		$output .= '<meta name="generator" content="WarriorPanel '. $warrior_panel_version .'"/>'. "\n";
		echo $output;
	}
}
add_action( 'wp_head', 'warrior_generators' );


/**
 * Warrior Header Codes
 *
 * Function to load custom codes in header
 */
 
function warrior_header_codes() {
	global $shortname;
	
	if (get_option($shortname.'_header_codes') <> "") {
		echo stripslashes( get_option($shortname.'_header_codes') ) . "\n";
	}
}
add_action( 'wp_head', 'warrior_header_codes' );


/**
 * Warrior Footer Codes
 *
 * Function to load custom codes in footer
 */
 
function warrior_footer_codes() {
	global $shortname;
	
	if (get_option($shortname.'_footer_codes') <> "") {
		echo stripslashes( get_option($shortname.'_footer_codes') ) . "\n";
	}
}
add_action( 'wp_footer', 'warrior_footer_codes' );


/**
 * Warrior Trim Title Function
 *
 * Function to cut string/text
 * @param Integer $length Word count
 * @return String The text after trim
 */

function warrior_post_title( $length, $cut = true ) {
	$title = get_the_title();
	mb_strlen( $title );
	
	if ( strlen($title) <= $length ) { 
	return $title;
	}
	
	$last_space = strrpos(substr($title, 0, $length), ' ');
	$cut_text = substr($title, 0, $last_space);
	
	
	if ($cut) {
		$cut_text .= '...';
	}
	
	return $cut_text;
}


/**
 * Warrior Excerpt Function
 *
 * Function to cut title
 * @param Integer $length Word count
 * @return String The text after trim
 */

function warrior_excerpt( $length, $ending = '...',  $cut = true ) {
	$excerpt = get_the_excerpt();
	mb_strlen( $excerpt );

	if ( strlen($excerpt) <= $length ) { 
		return $excerpt;
	}
	
	$last_space = strrpos(substr($excerpt, 0, $length), ' ');
	$cut_text = substr($excerpt, 0, $last_space);

	if ($cut) {
		$cut_text .= '...';
	}

	return $cut_text;
}


/**
 * Warrior Thumbnail
 *
 * Function to display thumbnail using post thumbnail or Timthumb
 */

function warrior_thumbnail($method, $width, $height, $post_thumb_image = '', $image_title = '') {
	global $post, $blog_id, $shortname, $multisite_image_path;
	
	// If using WordPress default post thumbnail
	if ( $method == 'post-thumbnail' ) {
		if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
			the_post_thumbnail($post_thumb_image);
		}
	} 
	// if using Timthumb
	elseif ( $method == 'timthumb' ) {
		if( get_post_meta($post->ID, "thumb", true) ) {
			$values = get_post_custom_values("thumb");
			
			if (isset($blog_id) && $blog_id > 0) {
				echo "<img src=\"". get_bloginfo('template_directory') ."/timthumb.php?src=". warrior_multisite_image_path($multisite_image_path) ."&amp;w=". $width ."&amp;h=". $height ."\" alt=\"". $image_title ."\" title=\"". $image_title ."\" />";
			} else {
				echo "<img src=\"". bloginfo('template_url') ."/timthumb.php?src=". $values[0] ."&amp;w=". $width ."&amp;h=". $height ."\" alt=\"". $image_title ."\" title=\"". $image_title ."\" />";
			}
		}
	// If automatically detect post thumbnail or Timthumb	
	} elseif ( $method == 'both' ) {
		if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
			the_post_thumbnail($post_thumb_image);
		} elseif ( get_post_meta($post->ID, "thumb", true) ) {
			$values = get_post_custom_values("thumb");
			
			// WordPress Multi Site
			if (isset($blog_id) && $blog_id > 0) {
				echo "<img src=\"". get_bloginfo('template_directory') ."/timthumb.php?src=". warrior_multisite_image_path($multisite_image_path) ."&amp;w=". $width ."&amp;h=". $height ."\" alt=\"". $image_title ."\" title=\"". $image_title ."\" />";
			} 
			// WordPress Single Instalation
			else {
				echo "<img src=\"". get_bloginfo('template_directory') ."/timthumb.php?src=". get_bloginfo('template_directory') ."/images/default-thumb.gif&amp;w=". $width ."&amp;h=". $height ."\" alt=\"". $image_title ."\" title=\"". $image_title ."\" />";
			}
		} else {
			// WordPress Multi Site
			if (isset($blog_id) && $blog_id > 0) {
				echo "<img src=\"". get_bloginfo('template_directory') ."/timthumb.php?src=/wp-content/themes/". $shortname ."/images/default-thumb.gif&amp;w=". $width ."&amp;h=". $height ."\" alt=\"". $image_title ."\" title=\"". $image_title ."\" />";
			} 
			// WordPress Single Instalation
			else {
				echo "<img src=\"". get_bloginfo('template_directory') ."/timthumb.php?src=". get_bloginfo('template_directory') ."/images/default-thumb.gif&amp;w=". $width ."&amp;h=". $height ."\" alt=\"". $image_title ."\" title=\"". $image_title ."\" />";
				
			}
		}
	}
}

// Timthumb image path fixed for WordPress Mutil Site
// Code is based on the code created by TimThumb author
function warrior_multisite_image_path ($post_id = null) {
	if ($post_id == null) {
		global $post;
		$post_id = $post->ID;
	}
	$multisite_image_path = get_post_meta($post_id, 'thumb', true);
	global $blog_id;
	if (isset($blog_id) && $blog_id > 0) {
		$image_parts = explode('/files/', $multisite_image_path);
		if (isset($image_parts[1])) {
			$multisite_image_path = '/blogs.dir/' . $blog_id . '/files/' . $image_parts[1];
		}
	}
	return $multisite_image_path;
}


/**
 * Warrior Admin Update Link
 *
 * Function to display or not display update link
 */

function warrior_admin_update_link() {
	global $shortname;
	
	if( get_option($shortname.'_update_link') == "Yes" ) :
		edit_post_link(__('Edit Post', 'warrior'), '<p class="edit-post">', '</p>');
	endif;
}

/**
 * Warrior IE6 Warning
 *
 * Function to load IE6 warning page
 */

function warrior_ie6_warning () {
	global $shortname;
	
	if( get_option($shortname.'_ie6_warning') == "Yes") {
		if ( strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE 6.') == true ) {
			include( TEMPLATEPATH . '/includes/ie6-warning.php' );
			exit;
		}
	}
}

/**
 * Warrior Theme Logo
 *
 * Function to add logo from WarriorPanel
 */

function warrior_logo() {
	global $shortname;
	
	if ( get_option($shortname.'_logo') <> "" ) {
			echo "<a href='". get_bloginfo('url')."'><img src='". get_option($shortname.'_logo') ."' alt='". get_bloginfo('name')."' title='". get_bloginfo('name') ."' /></a>";
	} else {
		echo "<a href='". get_bloginfo('url') ."'><img src='". get_bloginfo('template_url') ."/styles/". get_option($shortname.'_style') ."/images/logo.png' alt='". get_bloginfo('name') ."' title='". get_bloginfo('name')."' /></a>";
	}
}


/**
 * Warrior Favorite Icon
 *
 * Function to add favicon from WarriorPanel
 */

function warrior_favicon() {
	global $shortname;
	
	if( get_option($shortname.'_favicon') <> "" ) :
?>
	<link rel="shortcut icon" href="<?php echo get_option($shortname.'_favicon'); ?>" />
<?php else: ?>
	<link rel="shortcut icon" href="<?php bloginfo('template_url'); ?>/images/favicon.ico" />
<?php
	endif;
}
add_action('wp_head', 'warrior_favicon');


/**
 * Warrior Page view  process
 *
 * Function to count post and page view
 * this function update (or add) a new option with key 'warrior_views' to store the view counter for posts and pages
 * the 'warrior_views' option is an array with array structure array(post_id => counter)
 */

function warrior_page_view_process() {
	global $post;
	$count = false;
	$count_it = false;
	
	// If user view a single post or page then get the ID, it will used as a key for views array
	if (is_single() || is_page()) {
		$post_id = $post->ID; 
		$count_it = true;
	}
	// If user view homepage or archives page then the ID will set to 0, it will used as a key for homepage + archive page views
	if (is_home() || is_archive()) {
		$post_id = 0;
		$count_it = false;
	}
	if ($count_it) {
		if ($views = get_option('warrior_views')) {
			$last_views = get_option('warrior_last_views');
			if ( isset( $views[$post_id] )) {
				$views[$post_id] = $views[$post_id] + 1; // increment by 1 view for current post/page
			} else {
				$views[$post_id] = 1; // increment by 1 view for current post/page
			}
			$last_views[$post_id] = time();
			update_option('warrior_views', $views); // save the counter
			update_option('warrior_last_views',$last_views); // save the last time this page viewed
		} else {
			$views = array($post_id => 1 );
			$last_views = array($post_id => time() );
			add_option('warrior_views', $views );
		}
	}
}

add_action('wp_head', 'warrior_page_view_process');

/**
 * Warrior Page view 
 *
 * Function to return page view
 */

function warrior_page_view($post_id) {
	if ($views = get_option('warrior_views')) {
		if ( isset($views[$post_id]) )
			$page_view = $views[$post_id];
		else $page_view = 0;
	} else {
		$page_view = 0;
	}
		
	return $page_view;
}

/**
 * Warrior most viewed post 
 *
 * Function to display posts with most viewed
 * Parameter $limit : number of most viewed post to show
 */

function warrior_most_viewed_posts($limit = 5, $before='<li>', $after = '</li>') {
	if ($views = get_option('warrior_views')) {
	
		// exclude the homepage count
		$views[0] = false;
		
		// sort descending the array
		arsort($views, SORT_NUMERIC);
		$views = array_filter($views);
		// get the number of post to show, this according to $limit parameter that have default value 5
		$views = array_slice($views,0,$limit,true);
		
		foreach($views as $key=>$val) {
			$mypost = get_post($key);
			$title = $mypost->post_title;
			echo $before . "<a href='".get_permalink($key)."' title='".$title."'>". $title. " (".$val . __('Views', 'warrior').") </a>" . $after;
		}
	}
}


/**
 * Warrior views total 
 *
 * Function to return total viewer
 */

function warrior_views_total() {
	if ($views = get_option('warrior_views'))
	
		// sum the values
		$sum = array_sum($views);
	else
		$sum = 0;

	return $sum;
}


/**
 * Warrior Post Rating
 *
 * Function to show post rating, draw stars and show rating dropdown for browser with javascript disabled
 * Parameter $post_id
 */

function warrior_post_rating($post_id) {
	global $shortname;
	
	// create wordpress nonce for ajax submit verification
	$nonce = wp_create_nonce( 'ajax-post-'.$post_id.'-rating-nonce' ); 
	
	//Script below used to save rating via non ajax method
	if ( isset($_POST['rate-submit-'.$post_id]) ) {
		if ( isset($_POST['star-rate-select-'.$post_id]) ) {
			$rate = $_POST['star-rate-select-'.$post_id];
			warrior_post_rating_save($rate, $post_id);
		}
	}

	$anonymous_rate = get_option($shortname."_anonymous_rating");
	
	// Get the average rating, number of voter and current user rate.
	$avg = warrior_post_rating_avg($post_id);
	$voters = warrior_post_rating_voters($post_id);
	$yours = warrior_post_rating_yours($post_id);
	
	// If current user haven't rate yet we will print their rating to none rather than 0
	if ( $yours == 0 ) 
		$your_txt = 'none';
	else 
		$your_txt = $yours;
	
	$ceiled_avg = ceil($avg);
	$floored_avg = floor($avg);
	
	// Check if current user can rate this post or not
	$can_rate = warrior_can_rate($post_id);
	
?>
		<form id="post-rating-form" method="post">
		<div class="star-rating">
            <div class="star_rate_ajax">
            <label id="rate-title-<?php echo $post_id; ?>"><?php _e('Average :', 'warrior'); ?></label><br/>
        <?php 
			for( $j = 1; $j<=5; $j++) { 
			
				// Calculate the width of star in case average rating in decimal
				// Example : for average rating is 3.7 then we draw the fourth star width with 70%
				$diff = $j - ( $avg - $floored_avg );
				if ( $j <= $ceiled_avg ) $onclass = ' on'; else $onclass = '';
				if ( (($j - $avg) < 1) && (($j - $avg) > 0) )  $star_width = ' style="width:'. (($avg - $floored_avg)*100) .'%;"'; else $star_width = '';
				
				// If current user can rate this post we draw the star with link tag <a> 
				// But if if current user can rate then we draw with span tag
				if ( $can_rate ) :
			?>
            		<a href="#<?php echo $j; ?>" title="rate <?php echo $j; ?> star" class="rate<?php echo $onclass; ?>" id="<?php echo $j; ?>star-rate-<?php echo $post_id; ?>"><span<?php echo $star_width; ?>><?php _e('rate', 'warrior'); ?> <?php echo $j; ?> <?php _e('star', 'warrior'); ?></span></a>
            <?php 
				else : ?>
                	<span title="rate <?php echo $j; ?> star" class="rate<?php echo $onclass; ?>" id="<?php echo $j; ?>star-rate-<?php echo $post_id; ?>"><span<?php echo $star_width; ?>><?php _e('rate', 'warrior'); ?> <?php echo $j; ?> <?php _e('star', 'warrior'); ?></span></span>
            <?php 
				endif; ?>
		<?php } ?>	
                <input type="hidden" name="nonce-id-<?php echo $post_id; ?>" id="nonce-id-<?php echo $post_id; ?>" value="<?php echo $nonce; ?>" />
                <div id="rate-info-<?php echo $post_id; ?>" class="rate-info"><?php _e('Your rating: ', 'warrior'); ?> <?php echo $your_txt;?>, <?php _e('Average:', 'warrior'); ?> <?php echo $avg;?> (<?php echo $voters; ?> <?php _e('votes', 'warrior'); ?>)</div>
            </div>
            <?php
			
			// If user can rate this post then create form in case javascript disabled, this will be hidden if javascript enable
			if ( $can_rate ) : ?>
			<div class="hide-on-js">
				<label for="star-rate-select"><?php _e('Rate it','warrior'); ?></label>
					<select id="star-rate-select-<?php echo $post_id; ?>" name="star-rate-select-<?php echo $post_id; ?>">
						<option value="1"><?php _e('1 Star', 'warrior'); ?></option>
						<option value="2"><?php _e('2 Stars', 'warrior'); ?></option>
						<option value="3"><?php _e('3 Stars', 'warrior'); ?></option>
						<option value="4"><?php _e('4 Stars', 'warrior'); ?></option>
						<option value="5"><?php _e('5 Stars', 'warrior'); ?></option>
					</select>
				</label>
				<input type="submit" name="rate-submit-<?php echo $post_id;?>" value="<?php _e('Vote', 'warrior'); ?>" />
			</div>
            <?php
			endif; ?>
		</div>
		</form>
<?php
}


/**
 * Ajax handling function
 *
 * Function to handle ajax request/submit
 */
 
function warrior_post_rating_ajax_save() {
	// Get all parameter that thrown by ajax
	$post_id = $_POST['post_id'];
	$rate = $_POST['rate'];
	$nonce = $_POST['nonce'];
	
	// Verify nonce
	if ( ! wp_verify_nonce( $nonce, 'ajax-post-'.$post_id.'-rating-nonce' ) ) die ( $nonce );
	
	// Save rating
	warrior_post_rating_save($rate, $post_id);
	$avg = warrior_post_rating_avg($post_id);
	$voters = warrior_post_rating_voters($post_id);
	$yours = warrior_post_rating_yours($post_id);
	
	// Return the response to client browser
	echo 'success|'.$avg.'|'.$voters.'|'.$yours.'|other';
}

// Add action for ajax submit handler
add_action( 'wp_ajax_nopriv_ajax-rate', 'warrior_post_rating_ajax_save' );
add_action( 'wp_ajax_ajax-rate', 'warrior_post_rating_ajax_save' );


/**
 * Warrior post rating save
 *
 * Function to save user rating, rating saved as an array on post meta data with key _warrior_rating 
 *
 * Array structure for the saved rating :
 *    Array( 'summary' => ( sum total rating ), 'voter' => ( number of total voter ), 'detail' => ( Array of rating history) )
 *
 * Parameter $rate : user rating
 *           $post_id : post ID to be rate
 */
 
function warrior_post_rating_save($rate, $post_id) {
	global $shortname,  $current_user;

	get_currentuserinfo();
	$expire = get_option($shortname.'_rating_anonymous_expire');
	$enable_edit = get_option($shortname.'_replace_rating');;
	$userid = $current_user->ID;
	
	// Check wether user is login or not
	if ( $userid == 0 ) {
		// If user is not login, then this user treated as anonymous user
		// Use IP address as rating id
		$id = $_SERVER['REMOTE_ADDR'];
	} else {
		// If user is login then use the wordpress user id as rating id
		$id = $userid;
	}
	
	//Get now time
	$rate_date = date('Y-m-d H:i:s');
	
	// Check if this post has already a rate
	if ( $rate_history = get_post_meta($post_id, '_warrior_rating', true)) {
	
		// Get the rating history
		$details = $rate_history['detail'];
		
		// If this user have rate this post before
		if ( count($details[$id]) > 0 ) {	
			$last_time = $details[$id][0]['rate_date'];
			
			// If today pass the expire time since the last time this IP Address rate the post then treat this IP Address as a different user
			// Else replace the last rating point from the user with new one.
			if ( ( strtotime($rate_date) > strtotime('+'.$expire, $last_time ) ) && ( $userid == 0 ) && ( $expire != 'never' ) ) {
				array_unshift($details[$id], array('rate_date'=>strtotime($rate_date), 'rate' => $rate)); 
				$rate_history['summary'] = $rate_history['summary'] + $rate;
				$rate_history['voter'] = $rate_history['voter'] + 1;
			}elseif($enable_edit == 'Yes') {
				$rate_history['summary'] = $rate_history['summary'] - $details[$id][0]['rate'] + $rate;
				$details[$id][0]['rate_date'] = strtotime($rate_date);
				$details[$id][0]['rate'] = $rate;
			}
		// If this user never rate this post
		} else {
			$details[$id][0] = array('rate_date'=>strtotime($rate_date), 'rate' => $rate);
			$rate_history['summary'] = $rate_history['summary'] + $rate;
			$rate_history['voter'] = $rate_history['voter'] + 1;
		}
		$rate_history['detail'] = $details;
		
		// store the new rating on database
		update_post_meta($post_id, '_warrior_rating', $rate_history);
	} else {
		// Add new meta if no one already rate this post
		$detail = array( $id => array(array('rate_date' => strtotime($rate_date), 'rate' => $rate )));
		$post_rating = array( 'summary' => $rate, 'voter' => 1, 'detail' => $detail );
		add_post_meta($post_id,'_warrior_rating', $post_rating);
	}
	
}


/**
 * Get post rating average function
 *
 */

function warrior_post_rating_avg($post_id) {
	if ( $rating = get_post_meta($post_id, '_warrior_rating', true) ) $avg = round( $rating['summary'] / $rating['voter'], 1 );
	else $avg = 0;

	return $avg;
}


/**
 * Get number of voter
 *
 */

function warrior_post_rating_voters($post_id) {
	if ( $rating = get_post_meta($post_id, '_warrior_rating', true) ) $voters = $rating['voter'];
	else $voters = 0;
	
	return $voters;	
}


/**
 * Get Current user rating
 *
 */

function warrior_post_rating_yours($post_id) {
	global $shortname, $current_user;
	get_currentuserinfo();
	$expire = get_option($shortname.'_rating_anonymous_expire');
	$anonymous_rate = get_option($shortname."_anonymous_rating");
	$current_date = date('Y-m-d H:i:s');
	$userid = $current_user->ID;
	$your_vote = 0;
	if ($rating = get_post_meta($post_id, '_warrior_rating', true)) {
		if ( $userid == 0 ) {
			$id = $_SERVER['REMOTE_ADDR'];
			if ( isset($rating['detail'][$id]) && count($rating['detail'][$id]) > 0 && $anonymous_rate == 'Yes') {
				$last_time = $rating['detail'][$id][0]['rate_date'];
				if ( ( strtotime($current_date) > strtotime('+'.$expire, $last_time ) ) && ( $expire != 'never' ) ) {
					$your_vote = 0;
				} else {
					$your_vote = $rating['detail'][$id][0]['rate'];
				}
			} else {
				$your_vote = 0;
			}
		} else {
			$id = $userid;
			if ( count($rating['detail'][$id]) > 0 ) {
				$your_vote = $rating['detail'][$id][0]['rate'];
			} else {
				$your_vote = 0;
			}
		}
	}
	return $your_vote;
}


/**
 * Warrior can rate
 *
 * Check if user can rate this post or not
 * return true if user can rate and false if user cannot rate
 */

function warrior_can_rate($post_id) {
	global $shortname, $current_user;
	get_currentuserinfo();
	$expire = get_option($shortname.'_rating_anonymous_expire');
	$enable_edit = get_option($shortname.'_replace_rating');
	$anonymous_rate = get_option($shortname."_anonymous_rating");
	$userid = $current_user->ID;
	$had_rate = warrior_post_rating_yours($post_id) ;
	if ( $userid == 0 ) {
		if ( $anonymous_rate == 'Yes') {
			if ( $had_rate > 0 && $enable_edit == "No" )
				$can_rate = false;
			else
				$can_rate = true;
			
		} else {
			$can_rate = false;
		}
	} else {
		if ( $had_rate > 0 && $enable_edit == "No" )
			$can_rate = false;
		else
			$can_rate = true;
		
	}
	
	return $can_rate;
}


/**
 * Warrior ajax submit
 *
 * Javascript for post rating utility
 */

function warrior_post_rating_styles() {
	global $shortname;
	if( get_option($shortname.'_post_rating') == "Yes" ) {
?>
	<link rel="stylesheet" href="<?php echo get_bloginfo('template_url');?>/functions/warriorpanel/css/rating.css" media="all" />
	<script type="text/javascript">
		//<![CDATA[
		jQuery(document).ready( function($) {
			jQuery('.hide-on-js').hide();
			jQuery('.star_rate_ajax a.rate').click( function() {
				id = jQuery(this).attr('id');
				id_x = id.split('-');
				post_id = id_x[2];
				rate = id.charAt(0);
				nonce = jQuery('#nonce-id-' + post_id ).val();
									jQuery(this).addClass('on');
									jQuery(this).prevAll().addClass('on');
									jQuery(this).nextAll().addClass('off');
									jQuery(this).nextAll().removeClass('on');
									jQuery(this).siblings().find('span').css('width','100%');
				info_temp = jQuery('#rate-info-' + post_id).html();
				jQuery('#rate-info-' + post_id).html('Saving...');
				jQuery.post( "<?php echo admin_url('admin-ajax.php') ?>", 
							{ action : 'ajax-rate', post_id : post_id, rate : rate, nonce : nonce },
							function ( response ) {
								result = response.split('|');
								if ( result[0] == 'fail' ) {
									jQuery('#rate-info-' + post_id).html( info_temp );
								} else {
									info_new = '<?php _e('Your rating: ', 'warrior'); ?>' + result[3] + ', Average: ' + result[1] + ' (' + result[2] + ' votes)';
									jQuery('#rate-info-' + post_id).html( info_new );
									jQuery('#rate-title-' + post_id).data('temp','<?php _e('Your rating: ', 'warrior'); ?>');
									jQuery('#rate-title-' + post_id).html('<?php _e('Your rating: ', 'warrior'); ?>');
								}
							} );
				
				return false;
			});
			jQuery('.star_rate_ajax a.rate').mouseenter( function() {
				id = jQuery(this).attr('id');
				id_x = id.split('-');
				post_id = id_x[2];
				jQuery(this).addClass('active');
				jQuery(this).prevAll().addClass('active');
				jQuery(this).nextAll().addClass('off');
				jQuery('#rate-title-' + post_id).data('temp',jQuery('#rate-title-' + post_id).html());
				jQuery('#rate-title-' + post_id).html('<?php _e('Your rating: ', 'warrior'); ?>')
			});
			jQuery('.star_rate_ajax a.rate').mouseleave( function() {
				id = jQuery(this).attr('id');
				id_x = id.split('-');
				post_id = id_x[2];
				jQuery(this).removeClass('active');
				jQuery(this).prevAll().removeClass('active');
				jQuery(this).nextAll().removeClass('off');
				jQuery('#rate-title-' + post_id).html(jQuery('#rate-title-' + post_id).data('temp'));
			});
		});
		//]]>
	</script>
<?php
	}
}
if( get_option($shortname.'_post_rating') == "Yes" ) {
	add_action( 'wp_head', 'warrior_post_rating_styles' );
}


/**
 * Warrior Social Icons
 *
 * Function to echo the social icons list
 */
 
function warrior_social_icons() { 
	global $shortname;
	
	if ( get_option($shortname.'_feed') <> "" ) {
		echo "<a href='". get_option($shortname.'_feed')."'><img src='". get_bloginfo('template_url')."/images/icons/feed.png' alt='". __( 'Subscribe feed', 'warrior' )."' title='". __( 'Subscribe feed', 'warrior' )."' /></a>";
	}
	
	if ( get_option($shortname.'_twitter') <> "" ) {
		echo "<a href='". get_option($shortname.'_twitter')."'><img src='". get_bloginfo('template_url')."/images/icons/twitter.png' alt='". __( 'Follow us on Twitter', 'warrior' )."' title='". __( 'Follow us on Twitter', 'warrior' )."' /></a>";
	}
	
	if ( get_option($shortname.'_facebook') <> "" ) {
		echo "<a href='". get_option($shortname.'_facebook')."'><img src='". get_bloginfo('template_url')."/images/icons/facebook.png' alt='". __( 'Be our fans on Facebook', 'warrior' )."' title='". __( 'Be our fans on Facebook', 'warrior' )."' /></a>";
	}
	
	if ( get_option($shortname.'_myspace') <> "" ) {
		echo "<a href='". get_option($shortname.'_myspace')."'><img src='". get_bloginfo('template_url')."/images/icons/myspace.png' alt='". __( 'MySpace page', 'warrior' )."' title='". __( 'MySpace page', 'warrior' )."' /></a>";
	}
	
	if ( get_option($shortname.'_linkedin') <> "" ) {
		echo "<a href='". get_option($shortname.'_linkedin')."'><img src='". get_bloginfo('template_url')."/images/icons/linkedin.png' alt='". __( 'Linkedin profile', 'warrior' )."' title='". __( 'Linkedin profile', 'warrior' )."' /></a>";
	}
	
	if ( get_option($shortname.'_flickr') <> "" ) {
		echo "<a href='". get_option($shortname.'_flickr')."'><img src='". get_bloginfo('template_url')."/images/icons/flickr.png' alt='". __( 'Flickr photos', 'warrior' )."' title='". __( 'Flickr photos', 'warrior' )."' /></a>";
	}
	
	if ( get_option($shortname.'_youtube') <> "" ) {
		echo "<a href='". get_option($shortname.'_youtube')."'><img src='". get_bloginfo('template_url')."/images/icons/youtube.png' alt='". __( 'YouTube videos', 'warrior' )."' title='". __( 'YouTube videos', 'warrior' )."' /></a>";
	}
	
	if ( get_option($shortname.'_vimeo') <> "" ) {
		echo "<a href='". get_option($shortname.'_vimeo')."'><img src='". get_bloginfo('template_url')."/images/icons/vimeo.png' alt='". __( 'Vimeo videos', 'warrior' )."' title='". __( 'Vimeo videos', 'warrior' )."' /></a>";
	}
}

/**
 * Warrior Print Link
 *
 * Function to show a print link
 */
function warrior_print_link( $text = 'Print this page', $echo = 1 ){
	$link = '<a href="#" onclick="window.print();return false;" class="print-link" > ' . $text . '</a>';
	if ( $echo ) echo $link;
	return $link;
}


/**
 * Warrior Login Form
 *
 * Function to re-style wp-login.php
 */
function warrior_login_form() {
	global $shortname;
	
	add_filter('login_headerurl', 'change_wp_login_url');
	add_filter('login_headertitle', 'change_wp_login_title');
	add_action('login_head', 'change_wp_login_logo');
}
add_action( 'init', 'warrior_login_form' );


function change_wp_login_url() {
	global $shortname;
	
	if ( get_option($shortname.'_wp_login_logo_url') == 'Yes' ) {
		echo get_bloginfo('url');
	}
}

function change_wp_login_title() {
	global $shortname;
	
	if ( get_option($shortname.'_wp_login_logo_title') == 'Yes' ) {
		echo get_bloginfo('name');
	}
}

function change_wp_login_logo() {
	global $shortname;
	
	if ( get_option($shortname.'_wp_login_logo') != '' ) {
		echo '<style type="text/css">.login h1 a { background-image: url('.get_option($shortname.'_wp_login_logo').') !important; }</style>';
	}
}
?>