<?php
/**
 * Warrior Functions
 * List of files inclusion and functions
 */

/*	define global variables :
	$themename : theme name information
	$shortname : short name information
	$warrior_panel_version : current version of the WarriorPanel
	$version : current theme version
	$options : an array that represent the general theme options
	$seo_options : an array that represent the general theme SEO options
*/

global $themename, $shortname, $version, $warrior_panel_version, $options, $theme_options, $seo_options;
	
$themename = 'LaunchTime';
$shortname = 'launchtime';
$version = '1.0.0';

require_once(TEMPLATEPATH . "/functions/warriorpanel/admin-init.php"); // Load WarriorPanel

require_once(TEMPLATEPATH . "/functions/theme-options/theme-options.php"); // Load options
require_once(TEMPLATEPATH . "/functions/theme-options/theme-widgets.php"); // Load widgets
require_once(TEMPLATEPATH . "/functions/theme-options/theme-support.php"); // Load theme support
require_once(TEMPLATEPATH . "/functions/theme-options/theme-functions.php"); // Load custom functions
require_once(TEMPLATEPATH . "/functions/theme-options/theme-styles.php"); // Load JavaScript, CSS & comment list layout
?>